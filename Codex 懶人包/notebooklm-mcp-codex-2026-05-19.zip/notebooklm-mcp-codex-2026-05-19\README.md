# 2026-05-19 Codex App + NotebookLM MCP 打包紀錄

## 今日完成事項

1. 安裝並驗證 `kwota-daily-stack` Codex skill。
2. 將 `CLOUD_1.MD` 與每日工作報告同步到 Obsidian Second Brain。
3. 完成 NotebookLM CLI 登入與健康檢查。
4. 確認 `nlm notebook list --json --full` 可列出 notebooks。
5. 用 NotebookLM 查詢 `Neuro_David_Sussillo_大腦皮層動力學：高維神經計算的解析` notebook，整理今日讀書重點。
6. 修正 Codex App 的 NotebookLM MCP 設定。
7. 更新 `kwota-daily-stack` skill，補上 Codex App 連接 NotebookLM MCP 的規則與 fallback。

## Codex App MCP 設定

設定檔：

```text
C:\Users\User\.codex\config.toml
```

已加入並修正為：

```toml
[mcp_servers.notebooklm]
command = "C:\\Users\\User\\.local\\bin\\notebooklm-mcp.exe"
args = []
startup_timeout_sec = 20
tool_timeout_sec = 180
```

重點：Codex App 使用 TOML，不使用 Claude Desktop 的 JSON 設定檔。修改後需要重啟 Codex App，新的 MCP server 才會出現在工具清單。

## 驗證指令

```powershell
& "$env:USERPROFILE\.local\bin\nlm.exe" doctor
& "$env:USERPROFILE\.local\bin\nlm.exe" notebook list --json --full
```

本次驗證結果：

- `notebooklm-mcp-cli v0.6.10` 已安裝。
- `nlm.exe` 與 `notebooklm-mcp.exe` 位於 `C:\Users\User\.local\bin\`。
- cookies 與 CSRF token 存在。
- 登入帳號為 `kwotachu@gmail.com`。
- notebook 清單可讀取。

## Kwota Daily Stack 修正

已更新：

```text
C:\Users\User\.codex\skills\kwota-daily-stack\SKILL.md
```

新增內容包含：

- Codex App 的 NotebookLM MCP TOML 設定。
- NotebookLM CLI 健康檢查。
- `Authentication expired` 的修復方式。
- Codex sandbox 造成 `uv trampoline failed to canonicalize script path` 的判讀。
- Claude Desktop JSON 與 Codex TOML 的差異。
- 在 Codex 中自然語言呼叫 NotebookLM 的範例。
- 若目前 Codex session 尚未暴露 NotebookLM MCP tools，使用 `nlm.exe` CLI fallback。

驗證結果：

```text
Skill is valid!
```

## 今日 NotebookLM 讀書重點摘要

目標 notebook：

```text
Neuro_David_Sussillo_大腦皮層動力學：高維神經計算的解析
```

今日主軸：

- 以 `Computation Through Dynamics` 作為核心框架。
- 從 neural population state space trajectories 理解高維神經計算。
- 把 FORCE learning、fixed point analysis、dynamical motifs、null/potent space 串成一條讀書線。

建議 90 分鐘讀書安排：

1. 0-15 分鐘：Sussillo 的研究故事與 emergence。
2. 15-45 分鐘：FORCE learning 與 RLS。
3. 45-75 分鐘：fixed point、attractor 與 RNN reverse engineering。
4. 75-90 分鐘：回到 NeuroAI，整理 biological plausibility 與 Transformer 對照問題。

今日產出：

- 一張 `mechanism vs statistics` 對照表。
- 五個 attractor/function map。
- 三個博士級問題：causal/mechanistic equivalence、biological plausibility、language/reasoning scaling。

