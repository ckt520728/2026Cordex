# 2026-05-19 NotebookLM MCP 踩坑清單

## 1. 登入過期不是安裝失敗

錯誤：

```text
Authentication expired. Run 'nlm login' in your terminal to re-authenticate.
```

處理：

```powershell
& "$env:USERPROFILE\.local\bin\nlm.exe" login
```

登入成功後，再跑：

```powershell
& "$env:USERPROFILE\.local\bin\nlm.exe" doctor
```

## 2. 把設定檔路徑當成 PowerShell 指令

錯誤：

```text
CommandNotFoundException
```

原因：直接輸入 `C:\Users\User\AppData\Roaming\Claude\claude_desktop_config.json`，PowerShell 會把它當成要執行的命令。

正確做法：

```powershell
notepad "$env:APPDATA\Claude\claude_desktop_config.json"
notepad "$env:USERPROFILE\.codex\config.toml"
```

## 3. Claude Desktop JSON 和 Codex TOML 是兩套設定

Claude Desktop：

```text
C:\Users\User\AppData\Roaming\Claude\claude_desktop_config.json
```

Codex App：

```text
C:\Users\User\.codex\config.toml
```

Claude Desktop 的 JSON 不會讓 Codex App 自動取得 NotebookLM MCP tools。

## 4. Windows 路徑在 TOML 裡要跳脫

錯誤風險：

```toml
command = "C:\Users\User\.local\bin\notebooklm-mcp.exe"
```

穩定寫法：

```toml
command = "C:\\Users\\User\\.local\\bin\\notebooklm-mcp.exe"
```

## 5. Codex sandbox 可能造成假性 CLI 失敗

錯誤：

```text
uv trampoline failed to canonicalize script path
```

判讀：如果普通 PowerShell 或 Codex local permission 下 `nlm doctor` 正常，這是 Codex sandbox 權限造成的假性失敗，不代表 NotebookLM MCP 沒裝好。

## 6. 修改 Codex 設定後要重啟

`C:\Users\User\.codex\config.toml` 修改後，NotebookLM MCP 不會自動出現在同一個舊 session。需要重啟 Codex App 或開新 session。

